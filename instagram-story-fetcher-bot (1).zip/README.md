# Instagram Story Fetcher Bot

Telegram bot to fetch Instagram stories.
